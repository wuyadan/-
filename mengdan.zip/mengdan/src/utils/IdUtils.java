package utils;

import java.util.UUID;

//��ȡuuid
public class IdUtils {

	public static String getUUID() {

		return UUID.randomUUID().toString();

	}
}
