package dao;

import java.util.List;

import po.News;
public interface NewsDao {
	public List<News> getAllNews() throws Exception;
	
	public boolean addNews(News news) throws Exception;
	
	public News findNewsById(int n_id) throws Exception;
	
	public boolean editNews(News news) throws Exception;
	
	public boolean deleteNews(int n_id) throws Exception;
	
	public News getRecentNews() throws Exception;

}
