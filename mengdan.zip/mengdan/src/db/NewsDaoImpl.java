package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;

import dao.NewsDao;
import po.News;

public class NewsDaoImpl implements NewsDao {
	private Connection conn = null;

	private PreparedStatement pstmt = null;

	public NewsDaoImpl(Connection conn) {
		this.conn = conn;
	}
	//��̨ϵͳ����ѯ���еĹ���
	@Override
	public List<News> getAllNews() throws Exception {
		String sql = "select * from news order by n_id desc";
		Statement st = null;
		ResultSet rs = null;
		st = (Statement) conn.createStatement();
		rs = st.executeQuery(sql);
		List<News> newsList = new ArrayList<News>();
		News news;
		while (rs.next()) {
			int n_id = rs.getInt("n_id");
			String title = rs.getString("title");
			String details = rs.getString("details");
			news = new News();
			news.setN_id(n_id);
			news.setTitle(title);
			news.setDetails(details);
			String date = rs.getDate("n_time").toString();
			String time = rs.getTime("n_time").toString();
			news.setN_time(date + "��" + time);
			newsList.add(news);
		}
		return newsList;
	}

	//��̨ϵͳ�����ӹ���
	@Override
	public boolean addNews(News news) throws Exception {
		pstmt = null;
		String sql = "insert into news(n_id,title,details,n_time)value(null,?,?,sysdate());";
		int result = 0;
		pstmt = this.conn.prepareStatement(sql);
		pstmt.setString(1, news.getTitle());
		pstmt.setString(2, news.getDetails());
		result = pstmt.executeUpdate();
		pstmt.close();
		if (result == 1) {
			return true;
		}
		return false;
	}

	//��̨ϵͳ������id���ҹ���
	@Override
	public News findNewsById(int n_id) throws Exception {
		News news = null;
		ResultSet rs = null;
		String sql = "select * from news where n_id =?";
		pstmt = this.conn.prepareStatement(sql);
		pstmt.setInt(1, n_id);
		rs = pstmt.executeQuery();
		while (rs.next()) {
			news = new News();
			news.setN_id(rs.getInt("n_id"));
			news.setTitle(rs.getString("title"));
			news.setDetails(rs.getString("details"));
			news.setN_time(rs.getString("n_time"));
		}
		pstmt.close();
		rs.close();
		return news;
	}

	//��̨ϵͳ������id�޸ĵ�������
	@Override
	public boolean editNews(News news) throws Exception {
		pstmt = null;
		String sql = "update news set title=?,details=?,n_time=sysdate() where n_id="
				+ news.getN_id();
		int result = 0;
		pstmt = this.conn.prepareStatement(sql);
		pstmt.setString(1, news.getTitle());
		pstmt.setString(2, news.getDetails());
		result = pstmt.executeUpdate();
		pstmt.close();
		if (result == 1) {
			return true;
		}
		return false;
	}

	//��̨ϵͳ������idɾ������
	@Override
	public boolean deleteNews(int n_id) throws Exception {
		String sql = "delete from news where n_id=?";
		int result = 0;
		pstmt = this.conn.prepareStatement(sql);
		pstmt.setInt(1, n_id);
		result = pstmt.executeUpdate();
		pstmt.close();
		if (result == 1) {
			return true;
		}
		return false;
	}

	//ǰ̨ϵͳ����ѯ�������ӻ��޸ĵ�һ������
	public News getRecentNews() throws Exception {
		News news = null;
		ResultSet rs = null;
		String sql = "select * from news order by n_time desc limit 0,1";
		pstmt = this.conn.prepareStatement(sql);
		rs = pstmt.executeQuery();
		while (rs.next()) {
			news = new News();
			news.setN_id(rs.getInt("n_id"));
			news.setTitle(rs.getString("title"));
			news.setDetails(rs.getString("details"));
			news.setN_time(rs.getString("n_time"));
		}
		pstmt.close();
		rs.close();
		return news;
	}
}
