package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import po.Goods;
import dao.GoodsDao;
import com.mysql.jdbc.Statement;

public class GoodsDaoImpl implements GoodsDao {

	private Connection conn = null;

	private PreparedStatement pstmt = null;

	public GoodsDaoImpl(Connection conn) {
		this.conn = conn;
	}

	@Override
	public boolean addGoods(Goods goods) throws Exception {
		pstmt = null;
		String sql = "insert into goods(gid,gname,number,gphoto,types,price,carriage,paddress,described)value(null,?,?,?,?,?,?,?,?);";
		int result = 0;
		pstmt = this.conn.prepareStatement(sql);
		pstmt.setString(1, goods.getGname());
		pstmt.setInt(2, goods.getNumber());
		pstmt.setString(3, goods.getPhoto());
		pstmt.setString(4, goods.getType());
		pstmt.setFloat(5, goods.getPrice());
		pstmt.setFloat(6, goods.getCarriage());
		pstmt.setString(7, goods.getPaddress());
		pstmt.setString(8, goods.getDescribed());
		result = pstmt.executeUpdate();
		pstmt.close();
		if (result == 1) {
			return true;
		}
		return false;
	}

	@Override
	public boolean editGoods(Goods goods) throws Exception {
		pstmt = null;
		String sql = "update goods set gname=?,number=?,price=?,carriage=?,paddress=?,described=? where gid="
				+ goods.getGid();
		int result = 0;
		pstmt = this.conn.prepareStatement(sql);
		pstmt.setString(1, goods.getGname());
		pstmt.setInt(2, goods.getNumber());
		pstmt.setFloat(3, goods.getPrice());
		pstmt.setFloat(4, goods.getCarriage());
		pstmt.setString(5, goods.getPaddress());
		pstmt.setString(6, goods.getDescribed());
		result = pstmt.executeUpdate();
		pstmt.close();
		if (result == 1) {
			return true;
		}
		return false;
	}

	@Override
	public boolean deleteGoods(int gid) throws Exception {
		String sql = "delete from goods where gid=?";
		int result = 0;
		pstmt = this.conn.prepareStatement(sql);
		pstmt.setInt(1, gid);
		result = pstmt.executeUpdate();
		pstmt.close();
		if (result == 1) {
			return true;
		}
		return false;
	}

	@Override
	public Goods queryById(int gid) throws Exception {
		Goods goods = null;
		ResultSet rs = null;
		String sql = "select * from goods where gid =?";
		pstmt = this.conn.prepareStatement(sql);
		pstmt.setInt(1, gid);
		rs = pstmt.executeQuery();
		while (rs.next()) {
			goods = new Goods();
			goods.setGid(rs.getInt("gid"));
			goods.setGname(rs.getString("gname"));
			goods.setNumber(rs.getInt("number"));
			goods.setPhoto(rs.getString("gphoto"));
			goods.setType(rs.getString("types"));
			goods.setPrice(rs.getFloat("price"));
			goods.setCarriage(rs.getFloat("carriage"));
			goods.setPaddress(rs.getString("paddress"));
			goods.setDescribed(rs.getString("described"));
		}
		pstmt.close();
		rs.close();
		return goods;
	}

	@Override
	public int queryNumberById(int gid) throws Exception {
		ResultSet rs = null;
		String sql = "select number from goods where gid =?";
		int number = 0;
		pstmt = this.conn.prepareStatement(sql);
		pstmt.setInt(1, gid);
		rs = pstmt.executeQuery();
		if (rs.next()) {
			number = rs.getInt("number");
		}
		pstmt.close();
		rs.close();
		return number;
	}

	//
	@Override
	public List<Goods> getLatestGoods(int gid, String type) throws Exception {
		List<Goods> goodsList = new ArrayList<Goods>();
		Goods goods;
		ResultSet rs = null;
		String sql = "select gid,gname,price from goods where gid != ? and types=? order by gid desc limit 4";
		pstmt = this.conn.prepareStatement(sql);
		pstmt.setInt(1, gid);
		pstmt.setString(2, type);
		rs = pstmt.executeQuery();
		while (rs.next()) {
			goods = new Goods();
			goods.setGid(rs.getInt("gid"));
			goods.setGname(rs.getString("gname"));
			goods.setPrice(rs.getFloat("price"));
			goodsList.add(goods);
		}
		return goodsList;
	}

	@Override
	public List<Goods> getAllGoods() throws Exception {
		String sql = "select * from goods order by gid desc";
		Statement st = null;
		ResultSet rs = null;
		st = (Statement) conn.createStatement();
		rs = st.executeQuery(sql);
		List<Goods> goodsList = new ArrayList<Goods>();
		Goods goods;
		while (rs.next()) {
			int gid = rs.getInt("gid");
			String gname = rs.getString("gname");
			int number = rs.getInt("number");
			String gphoto = rs.getString("gphoto");
			String type = rs.getString("types");
			float price = rs.getFloat("price");
			float carriage = rs.getFloat("carriage");
			String paddress = rs.getString("paddress");
			String described = rs.getString("described");
			goods = new Goods();
			goods.setGid(gid);
			goods.setGname(gname);
			goods.setNumber(number);
			goods.setPhoto(gphoto);
			goods.setType(type);
			goods.setPrice(price);
			goods.setCarriage(carriage);
			goods.setPaddress(paddress);
			goods.setDescribed(described);

			goodsList.add(goods);
		}
		return goodsList;
	}

	@Override
	public String[] queryTypes() throws Exception {
		String sql = "select distinct types from goods";
		Statement st = null;
		ResultSet rs = null;
		st = (Statement) conn.createStatement();
		rs = st.executeQuery(sql);
		String[] types = new String[10];
		int i = 0;
		while (rs.next()) {
			types[i] = rs.getString("types");
			i++;
		}
		return types;
	}

	@Override
	public List<Goods> getTypeGoodsList(String type) throws Exception {
		List<Goods> goodsList = new ArrayList<Goods>();
		Goods goods;
		ResultSet rs = null;
		String sql = "select gid,gname from goods where types=? order by gid desc;";
		pstmt = this.conn.prepareStatement(sql);
		pstmt.setString(1, type);
		rs = pstmt.executeQuery();
		while (rs.next()) {
			goods = new Goods();
			goods.setGid(rs.getInt("gid"));
			goods.setGname(rs.getString("gname"));
			goodsList.add(goods);
		}
		return goodsList;
	}

}
