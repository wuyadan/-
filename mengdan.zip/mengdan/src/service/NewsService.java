package service;

import java.sql.SQLException;
import java.util.List;

import po.News;
import dao.NewsDao;
import db.DBConnection;
import db.NewsDaoImpl;

public class NewsService implements NewsDao {

	private DBConnection dbconn = null;

	private NewsDao dao = null;

	public NewsService() throws SQLException {
		this.dbconn = new DBConnection();
		this.dao = new NewsDaoImpl(this.dbconn.getConnection());
	}

	@Override
	public boolean addNews(News news) throws Exception {
		if (news != null) {
			return this.dao.addNews(news);
		}
		return false;
	}

	@Override
	public boolean editNews(News news) throws Exception {
		if (news != null) {
			return this.dao.editNews(news);
		}
		return false;
	}

	@Override
	public boolean deleteNews(int gid) throws Exception {
		if (this.dao.findNewsById(gid) != null & isInt(gid)) {
			return this.dao.deleteNews(gid);
		}
		return false;
	}

	@Override
	public News findNewsById(int n_id) throws Exception {
		if (isInt(n_id)) {
			return this.dao.findNewsById(n_id);
		}
		return null;
	}

	@Override
	public List<News> getAllNews() throws Exception {
		List<News> news=null;
		news=dao.getAllNews();
		return news;
	}

	//ǰ̨ϵͳ����ѯ�������ӻ��޸ĵ�һ������
		public News getRecentNews() throws Exception {
			try {
				return dao.getRecentNews();
			} catch (SQLException e) {
				throw new RuntimeException("��ѯ�������ӻ��޸ĵ�һ������ʧ�ܣ�");
			}
		}
		public boolean isInt(int index) {
			if (index == 0) {
				return false;
			}
			String str = String.valueOf(index);
			return str.matches("[0-9]+$");
		}

}
