package po;

/**
 * ��Ʒ
 * 
 */
public class Goods {

	// ����
	private int gid;
	// ��Ʒ��
	private String gname;
	// ������Ʒ����
	private int number;
	// ��Ʒ��Ƭ
	private String photo;
	// ��Ʒ����
	private String type;
	// �۸�
	private float price;
	// �˷�
	private float carriage;
	// ������ַ
	private String paddress;
	// ��Ʒ����
	private String described;

	public Goods() {

	}
	
	public int getGid() {
		return gid;
	}

	public void setGid(int gid) {
		this.gid = gid;
	}

	public String getGname() {
		return gname;
	}

	public void setGname(String gname) {
		this.gname = gname;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	
	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public float getCarriage() {
		return carriage;
	}

	public void setCarriage(float carriage) {
		this.carriage = carriage;
	}

	public String getPaddress() {
		return paddress;
	}

	public void setPaddress(String paddress) {
		this.paddress = paddress;
	}

	public String getDescribed() {
		return described;
	}

	public void setDescribed(String described) {
		this.described = described;
	}

}
