package factory;

import dao.*;
import service.GoodsService;
import service.UserService;
import service.NewsService;

public class DAOFactory {

	public static UserDao getUserServiceInstance() throws Exception {
		return new UserService();
	}
	public static GoodsDao getGoodsServiceInstance() throws Exception {
		return new GoodsService();
	}
	public static NewsDao getNewsServiceInstance() throws Exception {
		return new NewsService();
	}
}
