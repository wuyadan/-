package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import factory.DAOFactory;
import po.News;

/**
 * 
 *	��̨�޸Ĺ����servlet
 */
public class EditNewsServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doPost(req, resp);
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		try {
		News bean = new News();
		//��ȡ��������
		int n_id = Integer.parseInt(req.getParameter("n_id"));
		String title = req.getParameter("title");
		String details = req.getParameter("details");
		bean.setN_id(n_id);
		bean.setTitle(title);
		bean.setDetails(details);
		//����dao�㷽��
		DAOFactory.getNewsServiceInstance().editNews(bean);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		resp.sendRedirect(req.getContextPath() + "/ListNewsServlet");
	}
}
