package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import po.News;
import service.NewsService;

/**
 * 
 *	��̨����id��ѯ�����servlet
 */
public class FindNewsByIdServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doPost(req, resp);
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		NewsService nService;
		try {
			nService = new NewsService();
		//��ȡ����id
		String n_id = req.getParameter("n_id");
		int id=Integer.valueOf(n_id).intValue();
		News news = nService.findNewsById(id);
		req.setAttribute("n", news);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		req.getRequestDispatcher("/news/edit.jsp").forward(req, resp);
	}
}
