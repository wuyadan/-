package servlet;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import factory.DAOFactory;
import po.Goods;

/**
 * ��̨ϵͳ
 * ���ڱ༭��Ʒ��Ϣ��servlet
 */
public class EditProductServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
		// ����javaBean,���ϴ����ݷ�װ.
		Goods bean = new Goods();
		//��ȡ��������
		int gid = Integer.parseInt(request.getParameter("gid"));
		String gname = request.getParameter("gname");
		int number = Integer.parseInt(request.getParameter("number"));
		Float price = Float.parseFloat(request.getParameter("price"));
		Float carriage = Float.parseFloat(request.getParameter("carriage"));
		String paddress = request.getParameter("paddress");
		String described = request.getParameter("described");
		bean.setGid(gid);
		bean.setGname(gname);
		bean.setNumber(number);
		bean.setPrice(price);
		bean.setCarriage(carriage);
		bean.setPaddress(paddress);
		bean.setDescribed(described);
		//����dao�㷽��
		DAOFactory.getGoodsServiceInstance().editGoods(bean);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		response.sendRedirect(request.getContextPath() + "/ListProductServlet");
}
}
