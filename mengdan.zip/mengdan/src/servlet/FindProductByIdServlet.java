package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import po.Goods;
import service.GoodsService;

/**
 * 
 *	��̨����id��ѯ�����servlet
 */
public class FindProductByIdServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doPost(req, resp);
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		GoodsService service;
		try {
			service = new GoodsService();
		//��ȡ��Ʒid
		String gid = req.getParameter("gid");
		int id=Integer.valueOf(gid).intValue();
		Goods goods = service.queryById(id);
		req.setAttribute("p", goods);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		req.getRequestDispatcher("/jsp/edit.jsp").forward(req, resp);
	}
}
