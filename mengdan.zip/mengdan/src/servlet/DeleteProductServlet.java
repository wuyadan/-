package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.GoodsService;


/**
 * ��̨ϵͳ
 * ɾ����Ʒ��Ϣ��servlet
 */
public class DeleteProductServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// ��ȡ�����������Ʒid
		String gid = request.getParameter("gid");
		GoodsService service;
		
			try {
				service = new GoodsService();
			
			int id=Integer.valueOf(gid).intValue();
		
		// ����service���ɾ����Ʒ����
		
			service.deleteGoods(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		response.sendRedirect(request.getContextPath() + "/ListProductServlet");
		return;
	}

}
