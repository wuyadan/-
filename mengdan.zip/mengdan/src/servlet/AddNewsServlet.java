package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import factory.DAOFactory;
import po.News;

/**
 *	��̨���ӹ����servlet
 */
public class AddNewsServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doPost(req, resp);
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		try {
		News bean = new News();
		//��ȡ��������
		String title = req.getParameter("title");
		String details = req.getParameter("details");
		bean.setTitle(title);
		bean.setDetails(details);
		//����addNotice����
		DAOFactory.getNewsServiceInstance().addNews(bean);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		resp.sendRedirect(req.getContextPath() + "/ListNewsServlet");
	}
}
