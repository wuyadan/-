package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.NewsService;

/**
 * 
 *	��̨ɾ�������servlet
 */
public class DeleteNewsServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doPost(req, resp);
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String n_id = req.getParameter("n_id");
		NewsService nService;
		try {
		nService = new NewsService();
		//��ȡ�������������id
		int id=Integer.valueOf(n_id).intValue();
		//����dao�㷽��
			nService.deleteNews(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		resp.sendRedirect(req.getContextPath() + "/ListNewsServlet");
	}
}
